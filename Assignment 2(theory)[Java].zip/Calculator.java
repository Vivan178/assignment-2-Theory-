public class Calculator {

    // add two integers
    public int add(int a, int b) {
        return a + b;
    }

    // add two double values
    public double add(double a, double b) {
        return a + b;
    }

    // add three integers
    public int add(int a, int b, int c) {
        return a + b + c;
    }

    // subtract two integers
    public int subtract(int a, int b) {
        return a - b;
    }

    // multiply two double values
    public double multiply(double a, double b) {
        return a * b;
    }

    // divide two integers
    public double divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Division by zero is not allowed!");
        }
        return (double) a / b;
    }
}
