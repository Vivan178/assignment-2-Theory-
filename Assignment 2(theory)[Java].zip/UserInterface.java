import java.util.Scanner;

public class UserInterface {

    Calculator calc = new Calculator();
    Scanner sc = new Scanner(System.in);

    public void performAddition() {
        System.out.println("Choose type of addition:");
        System.out.println("1. Add two integers");
        System.out.println("2. Add two doubles");
        System.out.println("3. Add three integers");
        System.out.print("Enter choice: ");
        int choice = sc.nextInt();

        switch(choice) {
            case 1:
                System.out.print("Enter first integer: ");
                int a = sc.nextInt();
                System.out.print("Enter second integer: ");
                int b = sc.nextInt();
                System.out.println("Result: " + calc.add(a, b));
                break;

            case 2:
                System.out.print("Enter first double: ");
                double x = sc.nextDouble();
                System.out.print("Enter second double: ");
                double y = sc.nextDouble();
                System.out.println("Result: " + calc.add(x, y));
                break;

            case 3:
                System.out.print("Enter first integer: ");
                int p = sc.nextInt();
                System.out.print("Enter second integer: ");
                int q = sc.nextInt();
                System.out.print("Enter third integer: ");
                int r = sc.nextInt();
                System.out.println("Result: " + calc.add(p, q, r));
                break;

            default:
                System.out.println("Invalid choice!");
        }
    }

    public void performSubtraction() {
        System.out.print("Enter first integer: ");
        int a = sc.nextInt();
        System.out.print("Enter second integer: ");
        int b = sc.nextInt();
        System.out.println("Result: " + calc.subtract(a, b));
    }

    public void performMultiplication() {
        System.out.print("Enter first decimal number: ");
        double a = sc.nextDouble();
        System.out.print("Enter second decimal number: ");
        double b = sc.nextDouble();
        System.out.println("Result: " + calc.multiply(a, b));
    }

    public void performDivision() {
        System.out.print("Enter first integer: ");
        int a = sc.nextInt();
        System.out.print("Enter second integer: ");
        int b = sc.nextInt();

        try {
            System.out.println("Result: " + calc.divide(a, b));
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void mainMenu() {
        int choice;

        do {
            System.out.println("\n===== Calculator Application =====");
            System.out.println("1. Add Numbers");
            System.out.println("2. Subtract Numbers");
            System.out.println("3. Multiply Numbers");
            System.out.println("4. Divide Numbers");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch(choice) {
                case 1:
                    performAddition();
                    break;
                case 2:
                    performSubtraction();
                    break;
                case 3:
                    performMultiplication();
                    break;
                case 4:
                    performDivision();
                    break;
                case 5:
                    System.out.println("Thank you. Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while(choice != 5);
    }

    public static void main(String[] args) {
        UserInterface ui = new UserInterface();
        ui.mainMenu();
    }
}
